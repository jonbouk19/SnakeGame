package finalproject;

import java.awt.event.KeyEvent;
import java.util.ArrayList;
import processing.core.PApplet;
import processing.core.PImage;


/**
 * @author Jonathan Boukarim
 * 
 * Let's take the classical snake game. 
 * And have sheep eating hay.
 */
public class FinalProject extends PApplet {

	/**
	 * Keep Eclipse happy
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * We'll need a herd of sheep, hay to eat,
	 * and a score board to keep track of the score.
	 * These are our 3 game objects displayed on the screen,
	 * each with its own draw function.
	 */
	private HerdOfSheep baah;
	private Hay hay;
	private Score score;
	
	
	/**
	 * Keep track of the highest score the player reaches,
	 * as well as the paused state of the game.
	 */
	private int highestScore;
	private boolean gamePaused;
	
	
	/**
	 * Our sheep and hay images
	 */
	private PImage sheepImage, hayImage;

	/** 
	 * Setup the game.
	 */
	public void setup(){
		/**
		 * At the start of the game, the frame rate is 30 fps, 
		 * which means the difficulty level is set to intermediate.
		 */
		size(1200, 600);
		frameRate(30); 
		
		/** 
		 * Load our 2 images.
		 * Initialize our 3 game objects.
		 */
		sheepImage = loadImage("Sheep.png");
		hayImage = loadImage("hay.jpg");
		baah = new HerdOfSheep();
		hay = new Hay();
		score = new Score();
		
		/**
		 * Initialize our tracking variables.
		 */
		gamePaused = false;
		highestScore = 0;
	}
	
	/**
	 * Redraw the background and the 3 game objects.
	 */
	public void draw(){
		background(84, 84, 84);
		score.draw();
		hay.draw();
		baah.move();
		baah.draw();
		
	
		/**
		 * If hay was eaten, throw some more hay for the herd to eat,
		 * and add another sheep to the herd.
		 */
		if( dist(hay.getX(), hay.getY(), baah.getX().get(0), baah.getY().get(0)) < HerdOfSheep.SHEEP_PIXEL_LENGTH ){
			hay.generateLocation();
			baah.addLink();
		}

		/**
		 * Update high score, if necessary
		 */
		if(baah.getSizeOfHerd() > highestScore){
			highestScore = baah.getSizeOfHerd();
		}
	}

	/**
	 * Control movement of the herd of sheep with arrow keys
	 * 
	 * Space will toggle movement.
	 */
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
		switch(keyCode) { 
		case KeyEvent.VK_UP:
			baah.setDirection("UP"); 
			break;
		case KeyEvent.VK_DOWN:
			baah.setDirection("DOWN"); 
			break;
		case KeyEvent.VK_LEFT:
			baah.setDirection("LEFT");
			break;
		case KeyEvent.VK_RIGHT :
			baah.setDirection("RIGHT");
			break;
		case KeyEvent.VK_SPACE:
			toggleMovement();
			break;
		}
	}
	
	/**
	 * If game is active, pause it by disabling the call to draw().
	 * If game was paused, resume it by enabling the call to draw().
	 */
	public void toggleMovement() {
		gamePaused = !gamePaused;
		if (gamePaused) {
			noLoop();
		}
		else {
			loop();
		}
	}
	
	/**
	 * Allow the user to select the difficulty level of the game.
	 * By default, intermediate was chosen in the setup().
	 */
	public void keyReleased(KeyEvent e) {
		if (key == '1') {
			System.out.println("Level: Beginner");
			frameRate(5);
		}
		else if (key == '2') {
			System.out.println("Level: Intermediate");
			frameRate(30);
		}
		else if (key == '3') {
			System.out.println("Level: Expert");
			frameRate(60);
		}
	} 
	
	/**
	 * Our most important object: the herd of sheep.
	 */
	public class HerdOfSheep {
		
		/**
		 * How many sheep we have,
		 * how fat the sheep is (aka how much room it takes up in the line),
		 * which way the herd of sheep is moving
		 */
		private int sizeOfHerd; 
		private static final float SHEEP_PIXEL_LENGTH = 25;
		private String direction; 
		
		/**
		 * The x and y coordinates of each sheep in the herd.
		 */
		private ArrayList <Float> x = new ArrayList<Float>();
		private ArrayList <Float> y = new ArrayList<Float>();

		/**
		 * Initially, a herd consists of 1 sheep,
		 * in the center of the screen,
		 * without a direction (stationary).
		 */
		public HerdOfSheep(){
			sizeOfHerd = 1;
			x.add((float)width/2);
			y.add((float)height/2);			
			direction = null;
		}
		
		/**
		 * Getters and setters
		 */
		public ArrayList<Float> getX() {
			return x;
		}
		public ArrayList<Float> getY() {
			return y;
		}
		public int getSizeOfHerd() {
			return sizeOfHerd;
		}
		public void setDirection(String d) {
			direction = d;
		}

		/**
		 * Here we decide how our herd of sheep will move.
		 */
		public void move(){
			
			/**
			 * The 0th index of the array will represent the sheep in the front
			 * for the other sheep.
			 * 
			 * For sheep indexes 1 through length-1, simply set the 
			 * location of the current sheep to the sheep in front of them
			 */
			for(int i = sizeOfHerd - 1; i > 0; i = i -1 ){
				x.set(i, x.get(i - 1));
				y.set(i, y.get(i - 1)); 
			}
			
			/** 
			 * As for the sheep in the front (at the 0th index), 
			 * we need to decide which way he his going,
			 * and adjust his location by his length.
			 */
			if(direction != null && direction.equals("LEFT")){
				if (x.get(0) - SHEEP_PIXEL_LENGTH <= 0) {
					// herd fell off the edge of the world and died, let God create another herd
					baah = new HerdOfSheep();
				}
				else {
					x.set(0, x.get(0) - SHEEP_PIXEL_LENGTH);
				}
			}
			if(direction != null && direction.equals("RIGHT")){
				if (x.get(0) + SHEEP_PIXEL_LENGTH >= width) {
					/** 
					 * Herd fell off the edge of the world and died, let God create another herd.
					 */
					baah = new HerdOfSheep();
				}
				else {
					x.set(0, x.get(0) + SHEEP_PIXEL_LENGTH);
				}
			}

			if(direction != null && direction.equals("UP")){
				if (y.get(0) - SHEEP_PIXEL_LENGTH <= 0) {
					/** 
					 * Herd fell off the edge of the world and died, let God create another herd.
					 */
					baah = new HerdOfSheep();  
				}
				else {
					y.set(0, y.get(0) - SHEEP_PIXEL_LENGTH);
				}
			}

			if(direction != null && direction.equals("DOWN")){
				if (y.get(0) + SHEEP_PIXEL_LENGTH >= height) {
					/** 
					 * Herd fell off the edge of the world and died, let God create another herd.
					 */
					baah = new HerdOfSheep();  
				}
				else {
					y.set(0, y.get(0) + SHEEP_PIXEL_LENGTH);
				}
			}
			
			/**
			 * Let nextSheep begin as the 2nd sheep in the herd, down to the last sheep.
			 * See if the head sheep decided to kill off the rest of the herd, by
			 * checking if the the head sheep collided into any of the other sheep.
			 */
			for (int nextSheep = 1; nextSheep < sizeOfHerd; nextSheep++) {
				if (headOfSheepTackledAnotherGuy(nextSheep)) {
					/**
					 * That wild sheep killed the herd. Oh well, let God create another herd.
					 */
					baah = new HerdOfSheep();
				}
			}
			
		}
		
		/**
		 * Did the head sheep hit the next sheep in the line?
		 * 
		 * @param nextSheep
		 * @return
		 */
		public boolean headOfSheepTackledAnotherGuy(int nextSheep) {
			if( dist(x.get(0), y.get(0), x.get(nextSheep), y.get(nextSheep)) < SHEEP_PIXEL_LENGTH){
				return true;
			}
			else {
				return false;
			}
		}

		/**
		 * Draw our herd of sheep.
		 */
		public void draw(){
			for(int i = 0; i <sizeOfHerd; i++){
				stroke(179, 140, 198);
				fill(100, 0, 100);
				image(sheepImage, x.get(i), y.get(i), SHEEP_PIXEL_LENGTH, SHEEP_PIXEL_LENGTH);
			} 
		}

		/**
		 * Add a sheep to the herd.
		 */
		public void addLink(){
			x.add(x.get(sizeOfHerd-1) + SHEEP_PIXEL_LENGTH);
			y.add(y.get(sizeOfHerd-1) + SHEEP_PIXEL_LENGTH);
			sizeOfHerd++;
		}
	}
	
	/**
	 * The game object that the sheep will eat.
	 */
	public class Hay {

		/**
		 * Coordinates of the hay.
		 */
		private float x, y;

		/**
		 * Initially, generate random x and y 
		 * coordinates for the hay.
		 */
		public Hay(){
			generateLocation();
		}
		
		/**
		 * Getters.
		 * 
		 * @return
		 */
		public float getX() {
			return x;
		}
		public float getY() {
			return y;
		}

		/**
		 * Draw the hay.
		 */
		public void draw(){
			fill(190,0,100);
			image(hayImage, x, y, 25, 25);
		}

		/**
		 * Generate random x and y coordinates 
		 * for the hay.
		 */
		public void generateLocation(){
			x = (float)Math.random()*(width-100)+50;
			y = (float)Math.random()*(height-100)+50;
		}  
	}
	
	/**
	 * The score board.
	 */
	public class Score {
		
		/**
		 * Coordinates for the score board,
		 * current score,
		 * and high score.
		 */
		private final float xScoreBoard;
		private final float yScoreBoard;
		private final float xScores;		
		private final float yHighestScore;
		private final float yCurrentScore;

		/**
		 * Initialize the coordinates.
		 */
		public Score() {
			xScoreBoard = 20;
			yScoreBoard = height - 100;
			xScores = xScoreBoard + 10;
			yHighestScore = yScoreBoard + 30;
			yCurrentScore = yHighestScore + 30;
		}
		
		/** 
		 * Draw the score board,
		 * highest score,
		 * and current score.
		 */
		public void draw(){

			stroke(139, 69, 19); 
			fill(222, 184 ,135); 
			rect(xScoreBoard, yScoreBoard, 175, 75);
			
			fill(139, 69, 19);
			textSize(25);
			text( "Score: " + baah.getSizeOfHerd(), xScores, yCurrentScore);
			
			fill(139, 69, 19);
			textSize(25);
			text( "High Score: " + highestScore, xScores, yHighestScore);
		}
	}
}
